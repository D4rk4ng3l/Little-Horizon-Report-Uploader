<?php
/**
 * Created by JetBrains PhpStorm.
 * User: Darky
 * Date: 17.09.11
 * Time: 17:26
 * To change this template use File | Settings | File Templates.
 */
 
class Uploader_Exception extends Exception
{

}
