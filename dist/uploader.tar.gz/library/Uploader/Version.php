<?php
/**
 * Created by JetBrains PhpStorm.
 * User: Darky
 * Date: 18.09.11
 * Time: 03:31
 * To change this template use File | Settings | File Templates.
 */
 
class Uploader_Version
{
    const VERSION = '1.0.0';
    const DATE = '18.09.2011';
    const DATE_LONG = '18. September 2011';
}
