<?php
/**
 * Exception class for configuarion class.
 */
class Uploader_Config_Exception extends Uploader_Exception
{
}
